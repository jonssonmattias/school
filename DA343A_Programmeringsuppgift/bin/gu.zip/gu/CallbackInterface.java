package gu;

public interface CallbackInterface {
	public void update(Object result);
}
