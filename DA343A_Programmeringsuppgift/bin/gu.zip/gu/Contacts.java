package gu;
import java.net.*;
import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;


/**
 * Is used to create a contacts
 * 
 * @author Markus Masalkovski, Mattias J�nsson, Ramy Behnam, Lukas Rosberg, Sofie Ljungcrantz
 *
 */
public class Contacts extends JPanel implements ActionListener{
	private ObjectOutputStream oos;
	private ObjectInputStream ois;

	private JPanel panelNorth = new JPanel();
	private JPanel panelCenter = new JPanel();
	private JPanel panelSouth = new JPanel();

	private JLabel activeUsers = new JLabel("Active users");
	private JLabel yourContacts = new JLabel("Your contacts");

	private JButton addContact = new JButton("Add contact");
	private JButton removeContact = new JButton("Remove Contact");
	private JButton send = new JButton("Send to selected contacts");
	
	private DefaultListModel<String> activeUserListModel;
	private DefaultListModel<String> contactListModel;
	private JList userList;
	private JList contactList;

	private ArrayList<User> activeUserArrayList;
	private ArrayList<User> contactsArrayList;
	
	private ClientUI clientUI;
	
	/**
	 * Constructs a Contacts-object
	 * 
	 * @param clientUI the clientUI
	 */
	public Contacts(ClientUI clientUI) {
		this();
		this.clientUI=clientUI;
	}

	/**
	 * Constructs a Contacts-object
	 */
	public Contacts() {
		activeUserListModel = new DefaultListModel<String>();
		contactListModel = new DefaultListModel<String>();
		userList = new JList(activeUserListModel);
		contactList = new JList(contactListModel);
		
		userList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		contactList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		
		setLayout();
		setComponetSize();
		add(panelNorth, BorderLayout.NORTH);
		add(panelCenter, BorderLayout.CENTER);
		add(panelSouth, BorderLayout.SOUTH);
		panelNorth.add(activeUsers, BorderLayout.NORTH);
		panelCenter.add(yourContacts, BorderLayout.NORTH);
		panelCenter.add(new JScrollPane(contactList), BorderLayout.CENTER);
		panelSouth.add(addContact, BorderLayout.WEST);
		panelSouth.add(send, BorderLayout.CENTER);
		panelSouth.add(removeContact, BorderLayout.EAST);	
		panelNorth.add(new JScrollPane(userList), BorderLayout.CENTER);
		send.addActionListener(this);
		addContact.addActionListener(this);	
	}

	/**
	 * Creates the frame
	 */
	public void createFrame() {
		JFrame frame = new JFrame("Your contacts");
		frame.setPreferredSize(new Dimension(500,600));
		frame.setBounds(900,0,500,600);
		frame.setVisible(true);
		frame.pack();
		frame.getContentPane().add(this);
	}

	private void setLayout() {
		setLayout(new BorderLayout());
		panelNorth.setLayout(new BorderLayout());
		panelCenter.setLayout(new BorderLayout());
		panelSouth.setLayout(new BorderLayout());

	}

	private void setComponetSize() {
		contactList.setPreferredSize(new Dimension(70,100));
		userList.setPreferredSize(new Dimension(70,100));
		addContact.setPreferredSize(new Dimension(100,20));
		removeContact.setPreferredSize(new Dimension(120,20));
	}
	/**
	 * Displays the active users
	 * 
	 * @param arrayList the active users
	 */
	public void displayUsers(ArrayList<User> arrayList) {
		activeUserArrayList=arrayList;
		for(User u: arrayList) {
			String userName = u.getUsername();
			if(!activeUserListModel.contains(userName))// && !activeUserListModel.contains(clientUI.getClient().getUser().getUsername()))
				activeUserListModel.addElement(userName);
		}
	}
	private void test(ArrayList<String> alist) {
		activeUserArrayList = new ArrayList<>();
		for(String u : alist) {
			activeUserArrayList.add(new User(u,null));
		}
		for(String u : alist) {
			if(!activeUserListModel.contains(u))
				activeUserListModel.addElement(u);
		}
	}

	/**
	 * Sets the contacts
	 * 
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public void setContacts() throws FileNotFoundException, IOException {
		contactsArrayList=selectedItem(activeUserArrayList);
		int i=0;
		for(User u: contactsArrayList) {
			String u1 = contactsArrayList.get(i).getUsername();
			String u2 = u.getUsername();
			if(!u1.equals(u2)) {
				contactsArrayList.add(u);
				writeContactsToFile();
			}
			i++;
		}
		for(User u: contactsArrayList) {
			String userName = u.getUsername();
			if(!contactListModel.contains(userName))
				contactListModel.addElement(userName);
		}
	}
	
	private ArrayList<User> selectedItem(ArrayList<User> al) {
		int[] selectedIxUser = userList.getSelectedIndices();
//		int[] selectedIxContact = contactList.getSelectedIndices();
		ArrayList<User> selectedUsers = new ArrayList<>();
		for (int i = 0; i < selectedIxUser.length; i++) {
			Object sel = userList.getModel().getElementAt(selectedIxUser[i]);
			for(User u:al) {
				if(sel.equals(u.getUsername()))
					selectedUsers.add((User) u);
			}
		}
		userList.removeSelectionInterval(0,userList.getMaxSelectionIndex());
		return selectedUsers;
	}

	public static void main(String[] args) {
		Contacts contacts = new Contacts();
		ArrayList<String> list = new ArrayList<String>();
		list.add("123");
		list.add("fff");
		list.add("1524");
		list.add("1524");
		contacts.test(list);
		contacts.createFrame();
	}
	
	private void writeContactsToFile() throws FileNotFoundException, IOException {
		try(ObjectOutputStream oos = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("files/contacts.dat")))) {
			oos.writeInt(contactsArrayList.size());
			for(User u:contactsArrayList) {
				oos.writeObject(u);
				oos.flush();
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==send) {
			clientUI.setReciverList(selectedItem(activeUserArrayList));
		}
		if(e.getSource()==addContact) {
			try {
				setContacts();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
}



